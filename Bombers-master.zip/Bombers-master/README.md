# :boom::bomb::bomb::bomb: BOMBERs :bomb::bomb::bomb::boom:
***SMS/Email/Whatsapp/Twitter/Instagram 𝔹𝕠𝕞𝕓𝕖𝕣𝕤 ℂ𝕠𝕝𝕝𝕖𝕔𝕥𝕚𝕠𝕟. ♡ Also added collection of some Fake SMS utilities which helps in skip phone number based SMS verification by using a temporary phone number that acts like a proxy.*** 

| Status | Description | Color Code |
|--------|-------------|------------|
|Working| The Script is working. | ![Working](https://i.ibb.co/3FntR1c/1.png) |
|Not- Working| Scripts are not working Or need some modifications.|![Not-Working](https://i.ibb.co/wWtD8S6/2.png) |
|Others| Pending, Some anothers issues OR not checked that is it working or not.| ![Others](https://i.ibb.co/pQwqwcN/3.png)|


### SMS BOMBERS :calling: :boom:
| Sr.No. | Name | Description | Developed By | Status |
|--------|------|--------------|-------------|--------|
|1.| <a href="https://github.com/bhattsameer/Bombers/blob/master/SMS_bomber.py">Sms_bomber.py</a> | Sending continues sms from using one single link. NOTE: Sms_bomber.py is now working too Thanks to [Ghost](https://github.com/ghost). Also refer: <a href="https://github.com/bhattsameer/Bombers/blob/master/sms_bomber_updated.py">Sms_bomber_updated.py</a> | <a href="https://github.com/bhattsameer/Bombers/blob/master">bhattsameer</a>| ![Working](https://i.ibb.co/3FntR1c/1.png) |
|2.| <a href="https://github.com/bhattsameer/Bombers/blob/master/SMS_bomber_version2.py">Sms_bomber_version2.py</a> | Sending continues sms from using one Multiple links.| <a href="https://github.com/bhattsameer/Bombers/blob/master">bhattsameer</a>| ![Others](https://i.ibb.co/pQwqwcN/3.png)|
|3.| <a href="https://github.com/iMro0t/bomb3r">bomb3r 💣</a> |Sending continues sms from on specified mobile number (25 different sms providers) |<a href="https://github.com/iMro0t">iMro0t</a> | ![Working](https://i.ibb.co/3FntR1c/1.png) |
|4.| <a href="https://github.com/bhattsameer/Bombers/blob/master/numspy_bomber.py">numspy_bomber.py</a> | Numspy bomber sending multiple free messages using numspy module. (Currently not working need to update) |<a href="https://github.com/bhattsameer/Bombers/blob/master">bhattsameer</a>|![Others](https://i.ibb.co/pQwqwcN/3.png) |
|5.| <a href="https://github.com/Bhai4You/SmS-BomB">SmS-BomB</a>| Your Own SmS BomBer...!!! |[Bhai4You](https://github.com/Bhai4You) |![Others](https://i.ibb.co/pQwqwcN/3.png) |
|6.| <a href="https://github.com/KANG-NEWBIE/SpamSms">SpamSms</a> |Spamming mobile number with OTP.|<a href="https://github.com/KANG-NEWBIE">KANG-NEWBIE</a>|![Others](https://i.ibb.co/pQwqwcN/3.png)|
|7.| <a href="https://github.com/KANG-NEWBIE/C-SpamMasal">C-SpamMasal</a> |Spamming mobile number with OTP. |<a href="https://github.com/KANG-NEWBIE">KANG-NEWBIE</a>|![Others](https://i.ibb.co/pQwqwcN/3.png) |
|8.| <a href="https://github.com/jdleo/SMS-BOMBER">SMS-BOMBER</a> |SMS Bomber.|<a href="https://github.com/jdleo">jdleo</a>|![Others](https://i.ibb.co/pQwqwcN/3.png) |
|9.| <a href="https://github.com/TheSpeedX/TBomb">TBomb</a> |A free and open-source SMS/Call bombing application | <a href="https://github.com/TheSpeedX">TheSpeedX</a>|![Working](https://i.ibb.co/3FntR1c/1.png) |
|10.| <a href="https://github.com/shellvon/smsBomb">smsBomb</a> |SMS Bomber.| <a href="https://github.com/shellvon">shellvon</a>|![Others](https://i.ibb.co/pQwqwcN/3.png) |
|11.| <a href="https://github.com/aarnhub/sms-bomber">sms-bomber</a>| SMS Bomber. |<a href="https://github.com/aarnhub">aarnhub</a>|![Others](https://i.ibb.co/pQwqwcN/3.png) |
|12.| <a href="https://github.com/4nat/Reborn">Reborn SMS Bomber For Termux and Linux</a>|Reborn SMS Bomber. |<a href="https://github.com/4nat">4nat</a>|![Others](https://i.ibb.co/pQwqwcN/3.png) |
|13.| <a href="https://github.com/Nikait/ni_bomber">ni_bomber</a> |SMS Bomber |<a href="https://github.com/Nikait">Nikait</a>|![Not-Working](https://i.ibb.co/wWtD8S6/2.png) |
|14.| <a href="https://github.com/AvinashReddy3108/YetAnotherSMSBomber">YetAnotherSMSBomber</a>|Sms Bomber.|<a href="https://github.com/AvinashReddy3108">AvinashReddy3108</a>|![Not-Working](https://i.ibb.co/wWtD8S6/2.png) |
|15.| <a href="https://github.com/1d8/smsbomb">smsbomb</a>|Sms Bomber.|<a href="https://github.com/1d8">1d8</a>|![Others](https://i.ibb.co/pQwqwcN/3.png) |
|16.| <a href="https://github.com/anubhavanonymous/XLR8_BOMBER">XLR8_BOMBER</a>|Superfast SMS bomber for linux and termux, Also sends OTP to whatsapp. |<a href="https://github.com/anubhavanonymous">anubhavanonymous</a> |![Working](https://i.ibb.co/3FntR1c/1.png) |
|17.| <a href="https://github.com/ebankoff/Beast_Bomber">Beast_Bomber</a>|SMS, email, WhatsApp, Telegram, Discord bomber and DoS attacker|<a href="https://github.com/ebankoff">ebankoff</a> |![Working](https://i.ibb.co/3FntR1c/1.png) |

### EMAIL BOMBERS :e-mail: :boom:
| Sr.No. | Name | Description | Developed By | Status |
|--------|------|--------------|-------------|--------|
|1.| <a href="https://github.com/bhattsameer/Bombers/blob/master/Email_bomber.py">Email_bomber.py</a> |Sending continues email. Update with Outlook bomber as well |[xyzricky](https://github.com/xyzricky)|![Working](https://i.ibb.co/3FntR1c/1.png) |
|2.| <a href="https://github.com/zanyarjamal/Email-bomber">Email_bomber</a> |Sending continues email. |[zanyarjamal](https://github.com/zanyarjamal) |![Working](https://i.ibb.co/3FntR1c/1.png) |
|3.| <a href="https://github.com/MrMugiwara/Email-Bomb">Email_bomb</a> |Sending continues email using your yahoo and gmail account.|[MrMugiwara](https://github.com/MrMugiwara)|![Working](https://i.ibb.co/3FntR1c/1.png) |
|4.| <a href="https://github.com/MazenElzanaty/EmBomber">EmBomber</a>| Email Bomber. |<a href="https://github.com/MazenElzanaty">MazenElzanaty</a>|![Others](https://i.ibb.co/pQwqwcN/3.png)|
|5.| <a href="https://github.com/ncorbuk/Python---Email-Bomber">Python---Email-Bomber</a> | Email Bomber.| <a href="https://github.com/ncorbuk">ncorbuk</a>|![Working](https://i.ibb.co/3FntR1c/1.png) |
|6.| <a href="https://github.com/Curioo/emailpyspam">EmailPySpam</a> |Email Bomber.|<a href="https://github.com/Curioo">Curioo</a>|![Working](https://i.ibb.co/3FntR1c/1.png) |
|7.| <a href="https://github.com/Juniorn1003/Email-Spammer">Email-Spammer</a> | Email Bomber. | <a href="https://github.com/Juniorn1003">Juniorn1003</a>|![Working](https://i.ibb.co/3FntR1c/1.png) |
|8.| <a href="https://github.com/mohinparamasivam/Email-Bomber">Email-Bomber</a> |Email Bomber.|<a href="https://github.com/mohinparamasivam">mohinparamasivam</a>|![Working](https://i.ibb.co/3FntR1c/1.png) |
|9.| <a href="https://github.com/juzeon/fast-mail-bomber">Fast Mail Bomber</a> |Fast, multithreading, efficient and easy-to-use mail bombing/spamming tool. Sending mails via mailman services hosted by different providers. | <a href="https://github.com/juzeon">juzeon</a>|![Working](https://i.ibb.co/3FntR1c/1.png) |
|10.| <a href="https://github.com/everydaycodings/Email-Bomber">Email_Bomber_Version2</a> |Fast, multithreading, efficient and easy-to-use mail bombing/spamming tool. Sending mails To multiple Victims(Improved Version). | <a href="https://github.com/everydaycodings">everydaycodings</a>|![Working](https://i.ibb.co/3FntR1c/1.png) |
|11.| <a href="https://github.com/everydaycodings/Email-Bomber">Atomic Email Bomb</a> | A better Gmail bomber. | <a href="https://github.com/zeyad-mansour">zeyad-mansour</a>|![Working](https://i.ibb.co/3FntR1c/1.png) |
|12.| <a href="https://github.com/bagarrattaa/email-bomber">email-bomber</a> |this is a email bomber unlike other email bombers u don't need your gmail email id to use this. |[bagarrattaa](https://github.com/bagarrattaa) |![Working](https://i.ibb.co/3FntR1c/1.png) |
|13.| <a href="https://github.com/ebankoff/Beast_Bomber">Beast_Bomber</a>|SMS, email, WhatsApp, Telegram, Discord bomber and DoS attacker|<a href="https://github.com/ebankoff">ebankoff</a> |![Working](https://i.ibb.co/3FntR1c/1.png) |

### Whats-app Bombers :calling: :boom:
| Sr.No. | Name | Description | Developed By | Status |
|--------|------|--------------|-------------|--------|
|1.| <a href="https://github.com/bhattsameer/Bombers/blob/master/wbomb.py">wbomb.py</a>| Whatsapp-bomber sending multipal message to a single user.|<a href="https://github.com/bhattsameer/Bombers/blob/master">bhattsameer</a> Last Modified: [OnTheLink](https://github.com/OnTheLink)|![Working](https://i.ibb.co/3FntR1c/1.png)|
|2.| <a href="https://github.com/tbhaxor/whatabomb">whatabomb</a>  | Whats-app bomber GUI. | [tbhaxor](https://github.com/tbhaxor)|![Working](https://i.ibb.co/3FntR1c/1.png) |
|3.| <a href="https://github.com/rizwansoaib/WhatsApp-monitor">WhatsApp-Bomber</a> | WhatsApp Monitor+Bomber (Chrome Extension)| [rizwansoaib](https://github.com/rizwansoaib)|![Not-Working](https://i.ibb.co/wWtD8S6/2.png)|
|4.| <a href="https://github.com/macr1408/Whatsapp-scripts">WhatsApp-Spam</a> | WhatsApp-Spam scripts | [macr1408](https://github.com/macr1408)|![Others](https://i.ibb.co/pQwqwcN/3.png) |
|5.| <a href="https://github.com/ebankoff/Beast_Bomber">Beast_Bomber</a>|SMS, email, WhatsApp, Telegram, Discord bomber and DoS attacker|<a href="https://github.com/ebankoff">ebankoff</a> |![Working](https://i.ibb.co/3FntR1c/1.png) |

### Twitter Bombers :boom:
| Sr.No. | Name | Description | Developed By | Status |
|--------|------|--------------|-------------|--------|
|1.| <a href="https://github.com/bhattsameer/Bombers/blob/master/Twitter_bomber.py">Twitter_bomber.py</a> |Twitter-bomber this will allow spamming the twitter inbox of a person with the message you want, the person who is using this must make sure that the inbox of the user who will be spammed is open. | [akshaykalucha3](https://github.com/akshaykalucha3)|![Working](https://i.ibb.co/3FntR1c/1.png) |


### TEMP & Fake-SMS Collection:  
| Sr.No. | Name | Description | Developed By | Status |
|--------|------|--------------|-------------|--------|
|1.| <a href="https://github.com/sdushantha/tmpsms">tmpsms</a>| A temporary SMS utility right from your terminal written in POSIX sh. |[sdushantha](https://github.com/sdushantha)|![Working](https://i.ibb.co/3FntR1c/1.png) |
|2.| <a href="https://github.com/Narasimha1997/fake-sms">fake-sms</a>| A simple command line tool using which you can skip phone number based SMS verification by using a temporary phone number that acts like a proxy. |[Narasimha1997](https://github.com/Narasimha1997)|![Working](https://i.ibb.co/3FntR1c/1.png) |

### Others:
| Sr.No. | Name | Description | Developed By | Status |
|--------|------|--------------|-------------|--------|
|1.| https://mailspammer.cf | Email Spammer Website. Spam piles and piles of emails! |[WOLFIE_OG](https://github.com/WOLFIE-OG)|![Not-Working](https://i.ibb.co/wWtD8S6/2.png) |
|2.| <a href="https://github.com/HoneyPots0/HPomb">HPomb</a>|HPomb Call, SMS and mail bomber all in one. |[HoneyPots0](https://github.com/HoneyPots0)|![Others](https://i.ibb.co/pQwqwcN/3.png)|
|3.| <a href="https://github.com/b31ngD3v/bomberthon">bomberthon</a> |Best Bombing Tool with WhatsApp, Instagram, SMS bomber | [b31ngD3v](https://github.com/b31ngD3v)|![Working](https://i.ibb.co/3FntR1c/1.png)|
|4.| <a href="https://github.com/bhattsameer/Bombers/blob/master/spam.py">PySpam</a> | Spam for pc {not work on phone} | [timofey260](https://github.com/timofey260)|![Working](https://i.ibb.co/3FntR1c/1.png)|


## Contributors:

To keep this collection up-to-date need contributors who can add more mobile/email/whatsapp/twitter scripts and github repo here at one place.  
||||
|--------------|----------|----------|
|:octocat: [iMro0t](https://github.com/iMro0t)|:octocat: [akshaykalucha3](https://github.com/akshaykalucha3)|:octocat: [bagarrattaa](https://github.com/bagarrattaa)|
|:octocat: [rizwansoaib](https://github.com/rizwansoaib)|:octocat: [xyzricky](https://github.com/xyzricky)|  |
|:octocat: [scienceLabwork](https://github.com/scienceLabwork)|:octocat: [timofey260](https://github.com/timofey260)|  |
|:octocat: [cclauss](https://github.com/cclauss)|:octocat: [juzeon](https://github.com/juzeon)|  |
|:octocat: [rduttshukla](https://github.com/rduttshukla)|:octocat: [Ghost](https://github.com/ghost)| |  
|:octocat: [LucasNcipha](https://github.com/LucasNcipha)|:octocat: [everydaycodings](https://github.com/everydaycodings)| |
|:octocat: [zeyad-mansour](https://github.com/zeyad-mansour)|:octocat: [ebankoff](https://github.com/ebankoff)| |

## Note:

𝙄 𝙖𝙢 𝙣𝙤𝙩 𝙧𝙚𝙨𝙥𝙤𝙣𝙨𝙞𝙗𝙡𝙚 𝙛𝙤𝙧 𝙖𝙣𝙮 𝙩𝙝𝙞𝙣𝙜 𝙮𝙤𝙪 𝙙𝙤 𝙬𝙞𝙩𝙝 𝙩𝙝𝙞𝙨 𝙨𝙘𝙧𝙞𝙥𝙩
𝙏𝙝𝙞𝙨 𝙞𝙨 𝙟𝙪𝙨𝙩 𝙛𝙤𝙧 𝙡𝙚𝙖𝙧𝙣𝙞𝙣𝙜 𝙖𝙣𝙙 𝙠𝙣𝙤𝙬𝙡𝙚𝙙𝙜𝙚 𝙥𝙪𝙧𝙥𝙤𝙨𝙚.

## Please contribute!
Thanks everyone for your continued support!! For now I am archiving this project and making it read-only, if anyone wants to contribute please reach out.

